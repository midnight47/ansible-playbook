#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Encrypt password for use with Ansible playbooks.
"""

import getpass
import random
import crypt

p = getpass.getpass('Password to use: ')
ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
print crypt.crypt(p, '$6$%s$' % ''.join(random.choice(ALPHABET) for i in range(8)))
