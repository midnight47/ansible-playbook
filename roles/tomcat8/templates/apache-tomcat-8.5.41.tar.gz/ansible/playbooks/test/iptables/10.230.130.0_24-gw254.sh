#!/bin/bash

#Шаблон iptables для подсети 10.230.130.0/24
IPTABLES="/sbin/iptables"

DNS="10.230.144.11/32 10.230.144.12/32 10.230.144.14/32"  #виндовые сервера
NTP="10.230.130.254"  #шлюз
ZABBIX="10.230.144.29/32"
ANSIBLE="10.230.144.25/32"
GRAYLOG="10.230.144.54"
MAIL="109.71.231.27 109.71.231.33"
PROXY="10.230.143.1 10.230.143.2 10.230.143.9"

# Flush all current rules from iptables
$IPTABLES -F

# Set default policies for INPUT, FORWARD and OUTPUT chains
$IPTABLES -P INPUT ACCEPT
$IPTABLES -P FORWARD DROP
$IPTABLES -P OUTPUT ACCEPT

# Set access for localhost
$IPTABLES -A INPUT -i lo -j ACCEPT
 
# Accept packets belonging to established and related connections
$IPTABLES -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
$IPTABLES -A OUTPUT -m state --state ESTABLISHED -j ACCEPT

#DNS

#NTP
$IPTABLES -A OUTPUT -p udp -d $NTP --dport 123 -j ACCEPT 

iptables -A INPUT -s 10.230.130.0/24 -j DROP
iptables -A OUTPUT -d 10.230.130.0/24 -j DROP

source config.sh   #подключаем конфиг с правилами по матрице

# Просмотр
iptables -L --line-number
echo
echo "Adding DONE, maybe OK"
echo "Saving to rc, PSE wait!"
service iptables save
echo
service iptables reload
echo "Done"
